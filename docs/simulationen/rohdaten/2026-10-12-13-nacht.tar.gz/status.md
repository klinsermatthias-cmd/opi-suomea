Läufe v4 (22:55 UTC, nach zweitem Container-Neustart; Container wird bei Leerlauf zurückgefordert → Monitor alle 10 min hält aktiv). Skript sim-v3.mjs (= ae7e635):
r1-de-w19 DAYS=45 PV_FROM=12 (dtw) | r2-fi-w19 DAYS=45 PV_FROM=20 (main-wt) | e1-fi-grenz DAYS=50 OFFLINE_B=27-35 QUOTA_DAY=40 GEM_DOWN=42-45 | p1-de-langsam DAYS=70 P_BASE=0.65 | p2-de-schnell-handy DAYS=70 P_BASE=0.97 HANDY_EVERY=1 | p3-fi-pause DAYS=70 GAP=30-50 P_BASE=0.8
Teilergebnisse: *.teil1.out (v2, bis Tag 54–160), *.teil2.out (v3, bis Tag 22–26). Fertig: v4.done.
Neustart je Lauf (aus /home/user/opi-suomea): NP=$(npm root -g); (env <VARS> OUT=$S/<n>.json NODE_PATH=$NP node $S/sim-v3.mjs > $S/<n>.out 2>&1; echo "<n> exit $?" >> $S/v4.done) &
r1b-de-w19 DAYS=40 PV_FROM=8 (dtw), Skript sim-v5.mjs (8bb7719)
